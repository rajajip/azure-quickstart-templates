﻿#!/bin/bash
echo "Setting Up Application"
